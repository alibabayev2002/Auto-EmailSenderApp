<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class messageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('messages')->insert([
            'sender' => 'faiqlenkaranli@gmail.com',
            'receiver' => 'acemiyt23@gmail.com',
            'content' => "salam mamsmammsmamsmsmamsammasmmsmam?",

        ]);
    }
}

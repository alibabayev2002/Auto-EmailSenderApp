        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/blog/resources/views/layouts/footer.blade.php ENDPATH**/ ?>
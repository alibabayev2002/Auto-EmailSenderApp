<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <title>Laravel</title>
    </head>
    <body>
<?php /**PATH /Applications/MAMP/htdocs/blog/resources/views/layouts/header.blade.php ENDPATH**/ ?>
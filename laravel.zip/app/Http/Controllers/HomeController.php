<?php
  
namespace App\Http\Controllers;
  
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Auth;
  
class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth','verified']);
    }
  
    public function index()
    {
        $email = Auth::user()->email;
        $messages = DB::table('messages')->where('receiver',$email)->get();
        $users = DB::table('users')->get();

        return view('home')->with(['users'=>$users]);
    }
}
@extends('layouts.master')
@section('content')

<!-- <div class="p-5 w-100"> -->
<div class="container rounded w-25">

    <ul class="list-group">
        <li class="list-group-item  bg-danger text-white text-center pages-item">Task pages</li>
        <li class="list-group-item btn  text-center pages-item">Admin</li>
        <li class="list-group-item text-center btn pages-item"><a href="">Register</a></li>
        <li class="list-group-item text-center pages-item">Login</li>
        <!-- <li class="list-group-item">Vestibulum at eros</li> -->
    </ul>
</div>
<!-- </div> -->
@endsection

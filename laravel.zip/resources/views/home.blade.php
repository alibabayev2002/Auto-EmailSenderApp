@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- <div class="card"> -->
            <!-- <div class="card-header">{{ __('Mesaj qutusu') }}</div> -->

            <!-- <div class="card-body p-0"> -->
            @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
            @endif


            <div class="card">
                <div class="card-header">
                    Send message
                </div>
                <div class="card-body">
                    <form>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Mail multiple select</label>
                            <select multiple class="form-control" id="exampleFormControlSelect2">
                                @foreach($users as $user)
                                <option value="{{$user->id}}">{{$user->email}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Heftenin gunleri</label>
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Saat : </label>
                            <input placeholder="00:00" type="text" class="form-control" id="" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Mail title</label>
                            <input placeholder="Title" type="text" class="form-control" id="" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Mail content</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                        <input type="submit" value="GONDER" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
        @endsection
